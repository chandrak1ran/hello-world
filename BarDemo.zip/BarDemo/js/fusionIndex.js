const dataSource = {
  "chart": {
    "caption": "Historic World Population by Region",
    "placevaluesinside": "1",
    "showvalues": "0",
    "theme": "fusion"
  },
  "categories": [
    {
      "category": [
        {
          "label": "Africa"
        },
        {
          "label": "America"
        },
        {
          "label": "Asia"
        },
        {
          "label": "Europe"
        },
        {
          "label": "Oceania"
        }
      ]
    }
  ],
  "dataset": [
    {
      "seriesname": "Year 1800",
      "data": [
        {
          "value": "107"
        },
        {
          "value": "31"
        },
        {
          "value": "635"
        },
        {
          "value": "203"
        },
        {
          "value": "2"
        }
      ]
    },

    {
      "seriesname": "Year 1900",   
      "data": [
        {
          "value": "133"
        },
        {
          "value": "156"
        },
        {
          "value": "947"
        },
        {
          "value": "408"
        },
        {
          "value": "6"
        }
      ]
    },
		
    {
      "seriesname": "Year 2000",   
      "data": [
        {
          "value": "814"
        },
        {
          "value": "841"
        },
        {
          "value": "3714"
        },
        {
          "value": "727"
        },
        {
          "value": "31"
        }
      ]
    },
	{
      "seriesname": "Year 2016", 
      "data": [
        {
          "value": "1216"
        },
        {
          "value": "1001"
        },
        {
          "value": "4436"
        },
        {
          "value": "738"
        },
        {
          "value": "40"
        }
      ]
    }
  ],
  "trendlines": [
    {
      "line": [
        {
          "color": "#5D62B5",
          "thickness": "1.5",
          "displayvalue": "2017's Avg."
        },
        {
          
          "color": "#29C3BE",
          "thickness": "1.5",
          "displayvalue": "2018's Avg."
        }
      ]
    }
  ]
};

FusionCharts.ready(function() {
   var myChart = new FusionCharts({
      type: "msbar2d",
      renderAt: "chart-container",
      width: "100%",
      height: "400",
      dataFormat: "json",
      dataSource
   }).render();
});