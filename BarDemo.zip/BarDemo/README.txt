A Pen created at CodePen.io. You can find this one at https://codepen.io/n3okod3r/pen/PVVzyN.

 