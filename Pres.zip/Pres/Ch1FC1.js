const dataSource = {
  "chart": {
    "caption": "Sales in Millions Fusion Charts",
    "yaxisname": "Percentage %",
    "subcaption": "From 2008 to present",
    "showhovereffect": "1",
    "numbersuffix": "%",
    "drawcrossline": "1",
    "plottooltext": "<b>$dataValue</b> of youth were on $seriesName"
  },
  "categories": [
    {
      "category": [
        {
          "label": "Q1 2018"
        },
        {
          "label": "Q2 2018"
        },
        {
          "label": "Q3 2018"
        },
        {
          "label": "Q4 2018"
        }
      ]
    }
  ],
  "dataset": [
    {
      "seriesname": "Asia Pacific",
      "data": [
        {
          "value": "62"
        },
        {
          "value": "64"
        },
        {
          "value": "64"
        },
        {
          "value": "66"
        }
      ]
    },
    {
      "seriesname": "North America",
      "data": [
        {
          "value": "16"
        },
        {
          "value": "28"
        },
        {
          "value": "34"
        },
        {
          "value": "42"
        }
      ]
    },
    {
      "seriesname": "Australia",
      "data": [
        {
          "value": "20"
        },
        {
          "value": "22"
        },
        {
          "value": "27"
        },
        {
          "value": "22"
        }
      ]
    },
    {
      "seriesname": "Europe",
      "data": [
        {
          "value": "18"
        },
        {
          "value": "19"
        },
        {
          "value": "21"
        },
        {
          "value": "21"
        }
      ]
    },
	{
      "seriesname": "UAE",
      "data": [
        {
          "value": "18"
        },
        {
          "value": "19"
        },
        {
          "value": "21"
        },
        {
          "value": "21"
        }
      ]
    }
  ]
};

FusionCharts.ready(function() {
   var myChart = new FusionCharts({
      type: "msline",
      renderAt: "chart-container",
      width: "100%",
      height: "400",
      dataFormat: "json",
      dataSource
   }).render();
});