$(document).ready(function() {
        var chart = new Highcharts.Chart({
            chart: {
                renderTo: 'container',
                type: 'line',
                plotBorderWidth: 1,
                plotBorderColor: '#3F4044',
                borderColor: '#a1a1a1',
                borderWidth: 2,
                borderRadius: 3
            },
            title: {
                text: 'Sales in Millions Highcharts'
            },
            subtitle: {
                text: 'From 2008 to present'
            },
            legend: {
                align: 'right',
                verticalAlign: 'middle',
                layout: 'vertical',
            },
            xAxis: {
                categories: [ 'Q1 2018','Q2 2018','Q3 2018','Q4 2018'],
                /*tickInterval: 3*/
            },
            yAxis: {
                title: {
                    text: 'Percentage %'
                },
                min: 0
            },
            plotOptions: {
				line: {
					dataLabels: {
						enabled: true
					},
					enableMouseTracking: false
				},
                series: {
                    lineWidth: 2
                }
            },
            series: [{
                name: 'Asia Pacific',
                data: [54.7, 54.7, 53.9]
            }, {
                name: 'North America',
                data: [36.4, 36.5, 37.0, 39.1]
            }, {
                name: 'Australia',
                data: [ null, 56.0, 78.9, 23.4]
            }, {
                name: 'Europe',
                data: [ 1.9, 2.0, 2.1, 2.2]
            }, {
                name: 'UAE',
                data: [ 1.4, 1.4, 1.4, 1.4]
            }]
        });
    });